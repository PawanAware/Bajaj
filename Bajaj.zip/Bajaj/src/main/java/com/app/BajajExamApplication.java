package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BajajExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(BajajExamApplication.class, args);
	}

}
